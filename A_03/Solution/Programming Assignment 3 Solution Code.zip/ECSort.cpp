#include <vector>
using namespace std;

static void ECSortRange(vector<int> &listInts, int p1, int p2)
{
  // make [p1,p2] sorted
  if( p1 < p2)
  {
    int p = (p1+p2)/2;
    ECSortRange(listInts, p1, p);
    ECSortRange(listInts, p+1, p2);
    
    // now merge
    vector<int> listSorted;
    int px=p1, py=p+1;
    while(px<=p && py<=p2)
    {
      if( listInts[px] <= listInts[py] )
      {
        listSorted.push_back( listInts[px] );
        ++px;
      }
      else
      {
        listSorted.push_back( listInts[py] );
        ++py;
      }
    }
    // push any remaining stuff
    for(int i=px; i<=p; ++i)
    {
      listSorted.push_back( listInts[i] );
    }
    for(int i=py; i<=p2; ++i)
    {
      listSorted.push_back( listInts[i] );
    }
    // now copy back
    for(int i=0; i<(int)listSorted.size(); ++i)
    {
      listInts[i+p1] = listSorted[i];
    }
  }
}

void ECSort(vector<int> &listInts)
{
  // Sort the numbers in the list
  // implement merge sort
  ECSortRange(listInts, 0, (int)listInts.size()-1);
}

