#include <vector>
#include <iostream>
using namespace std;

// Your first C++ program is here...
int ECBinarySearch(const vector<int> &listNumbers, int value)
{
  // input list of numbers comes as listNumbers vector
  // You need to implement binary search of "value" over this list; 
  // return the position (i.e., array index) of the vector that matches "value"; 
  // or return -1 if not found.
  int l = 0; 
  int r = (int)listNumbers.size()-1;
  while (l <= r) 
  { 
    int m = l + (r-l)/2; 
  
    // Check if x is present at mid 
    if (listNumbers[m] == value)  
        return m;   
  
    // If x greater, ignore left half   
    if (listNumbers[m] < value)  
    {
        l = m + 1;  
    }
    // If x is smaller, ignore right half  
    else 
    {
         r = m - 1;  
    }
  } 
  
  // if we reach here, then element was not present 
  return -1;  
}

