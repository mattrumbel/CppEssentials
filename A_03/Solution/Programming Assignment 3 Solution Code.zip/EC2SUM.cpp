#include <vector>
#include "ECSort.h"
#include "ECBinSearch.h"
#include "EC2SUM.h"

using namespace std;

void EC2SUM( const vector<int> &listNumbers, 
  const vector<int> &listTargets, vector<bool> &list2SUMRes )
{
  // for each number x = listTargets[i], if there are two numbers 
  // in listNumbers that add up to x, then list2SUMres[i]=true 
  // otherwise, list2SUMRes[i]=false
  vector<int> listNumbersUse = listNumbers;
  ECSort(listNumbersUse);
  
  for(int i=0; i<(int)listTargets.size(); ++i)
  {
    bool fBS = false;
    for(int j=0; j<(int)listNumbersUse.size(); ++j)
    {
      // perform binary search on 
      int valTarg = listTargets[i] - listNumbersUse[j];
      int pBS = ECBinarySearch( listNumbersUse, valTarg );
      if( pBS >= 0 )
      {
        fBS = true;
        break;
      }
    }
    list2SUMRes.push_back(fBS);
  }
  
}

