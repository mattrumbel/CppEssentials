#ifndef ECBINSEARCH_H
#define ECBINSEARCH_H

#include <vector>

// Your first C++ program is here...
int ECBinarySearch(const std::vector<int> &listNumbers, int value);

#endif  // ECBINSEARCH_H
