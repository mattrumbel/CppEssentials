#ifndef EC2SUM_H
#define EC2SUM_H

#include <vector>

// Your first C++ program is here...
void EC2SUM( const std::vector<int> &listNumbers, const std::vector<int> &listTargets, std::vector<bool> &list2SUMRes );

#endif  // EC2SUM_H
