#include <vector>
using namespace std;

void ECSort(vector<int> &listInts)
{
  // Sort the numbers in the list
}

