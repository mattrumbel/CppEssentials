#ifndef ECSORT_H
#define ECSORT_H

#include <vector>

// Sort the numbers in listInts 
void ECSort(std::vector<int> &listInts);

#endif  // ECSORT_H
