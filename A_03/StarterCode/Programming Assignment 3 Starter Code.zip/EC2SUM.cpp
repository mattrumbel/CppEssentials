#include <vector>
using namespace std;

void EC2SUM( const vector<int> &listNumbers, 
  const vector<int> &listTargets, vector<bool> &list2SUMRes )
{
  // for each number x = listTargets[i], if there are two numbers 
  // in listNumbers that add up to x, then list2SUMres[i]=true 
  // otherwise, list2SUMRes[i]=false
}


