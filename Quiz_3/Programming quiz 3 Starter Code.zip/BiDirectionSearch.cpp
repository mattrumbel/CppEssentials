#include <vector>
using namespace std;

void ECBidirectionSearch( const vector<int> &listNums, int pos, vector<int> &listNumsBS)
{
    // store the numbers in listNums in the order of bidirectional search into listNumsBS
   // pos: initial position of the bidirectional search
   // your code goes here
}
