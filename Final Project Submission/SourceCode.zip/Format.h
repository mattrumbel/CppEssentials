#ifndef Format_h
#define Format_h

#include <vector>
#include "Document.h"
#include <string>
#include <sstream>

using namespace std;

class Format {
    public:
        virtual ~Format() {};
        virtual vector<string> GetFormatText(vector<vector<char>*> *text, int length, int currRow) = 0;
};

class SublimeFormat : public Format {
    public:
        SublimeFormat(int mr, int mc) : max_row(mr), max_col(mc) {};
        ~SublimeFormat();
        vector<string> GetFormatText_v2(vector<vector<char>*> *text, int length, int currRow);
        vector<string> GetFormatText(vector<vector<char>*> *text, int length, int currRow);
    private:
        int max_row;
        int max_col;
};

class WordFormat : public Format {
    public:
        WordFormat(int mr, int mc) : max_row(mr), max_col(mc) {};
        ~WordFormat();
        vector<string> GetFormatText(vector<vector<char>*> *text, int length, int currRow);
    private:
        vector<string> Wrap(vector<char> *text, int length, int currRow);
        vector<string> special_format;
        int max_row;
        int max_col;
};

#endif