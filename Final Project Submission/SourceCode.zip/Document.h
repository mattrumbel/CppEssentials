#ifndef Document_h
#define Document_h

#include <vector>
#include <string>

using namespace std;

class Document {
    public:
        Document(int argc, char *argv[], int max_rows, int max_cols);
        ~Document();
        // There are several commands to support
        // Character insertion
        void CharInsert(int row, int col, char c);
        void UndoCharInsert(int row, int col);
        // Character deletion
        char CharDelete(int row, int col);
        void UndoCharDelete(int row, int col, char c);
        // Row insertion
        void RowInsert(int row, int col);
        void UndoRowInsert(int row, int col);
        // Row deletion
        int RowDelete(int row);
        void UndoRowDelete(int row, int col);

        void MoveCursorRight();
        void MoveCursorLeft();
        void MoveCursorDown();
        void MoveCursorUp();

        int GetCol();
        int GetRow();

        int GetRowTrack();

        vector<string> StatusBar();
        //vector<string> GetAllLines();   
        vector<vector<char>*>* GetAllLines();

        void PopulateDocument(char *argv[]);
        void WriteToDocument();

        void SetScreenParams(int rows, int cols);
        
    private:
        int TranslatePos(int row, int col);
        vector<vector<char>*> paragraphs;
        int col_track;
        int row_track;
        int total_chars;
        string file_name;
        int screen_row_max;
        int screen_col_max;
};


#endif