// Test code for editor
#include "ECTextViewImp.h"
#include "EditorController.h"
#include "Document.h"
#include <iostream>

using namespace  std;

int myCounter = 0;

int main(int argc, char *argv[])
{

    // ECTextViewImp wndTest;
    // wndTest.AddRow("");
    // wndTest.AddRow("CSE 3150");
    // wndTest.AddRow("This is a very simple demo of the ECTextViewImp functionalities.");
    // wndTest.AddRow("Press ctrl-q to quit");    
    // wndTest.Show();

    // Document d;
    // cout << "Start Doc Manipulation" << endl;
    // d.AddStringRow(0, "");
    // d.PrintLines();
    // cout << "Row:" << d.GetRow() << endl;
    // cout << "Col:" << d.GetCol() << endl;

    EditorController ec(argc, argv);

    
    return 0;
}
