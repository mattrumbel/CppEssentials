#include "Format.h"

SublimeFormat::~SublimeFormat() {}
vector<string> SublimeFormat::GetFormatText_v2(vector<vector<char>*> *text, int length, int currRow) {
    vector<string> vs;
    vector<char> vc;
    for (vector<char> *v : *text) {
        vc = *v;
        string str(vc.begin(), vc.end());
        vs.push_back(str);
    }
    return vs;
}

vector<string> SublimeFormat::GetFormatText(vector<vector<char>*> *text, int length, int currRow) {
    vector<string> vs;
    vector<char> vc;

    int start_index = max_row * (currRow / max_row);
    for (int i = start_index; (i < (start_index + max_row)) && (i < text->size()); i++) {
        vc = *text->at(i);
        string str(vc.begin(), vc.end());
        vs.push_back(str);
    }

    return vs;
}


WordFormat::~WordFormat() {}
vector<string> WordFormat::GetFormatText(vector<vector<char>*> *text, int length, int currRow) {
    vector<string> vs;

    if (text->size() == 0) return vector<string>();

    for (vector<char>* t : *text) {
        for (string s : Wrap(t, length, currRow)) vs.push_back(s);
    }

    special_format = vs;
    return vs;
}

vector<string> WordFormat::Wrap(vector<char> *text, int length, int currRow) {
    vector<string> vs;

    vector<string> words;

    if (text->size() == 0) return vector<string>();
    
    istringstream ss(string(text->begin(), text->end()));
    while (ss) {
        string word;
        ss >> word;
        words.push_back(word);
    }

    // Words contains all broken up words, not make lines so that everything is OK.
    int len = 0;
    vs.push_back(string());
    vs[vs.size() -1] += words[0];
    len = words[0].size();

    for (int i = 1; i < words.size() - 1; i++) {
        string &w = words[i];
        if (len + w.size() + 1 < length) {
            vs[vs.size() - 1] += (" " + w);
            len += w.size() + 1;
        }
        else {
            vs.push_back(string());
            vs[vs.size() - 1] += w;
            len = w.size();
        }
    }
    return vs;
}

