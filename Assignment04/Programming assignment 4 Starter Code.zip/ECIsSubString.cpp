#include <vector>
using namespace std;

bool IsSubString( const std::vector<char> &strInput, 
  const std::vector<char> &strPattern )
{
// Concatenate two strings - 1) strConcatTo 2) strConcating.
// That is, you need to append the string strConcating to the end of strConcatTo.
// Result: strConcatTo passed to as input should contain the Concatenated string.
return false;
}


